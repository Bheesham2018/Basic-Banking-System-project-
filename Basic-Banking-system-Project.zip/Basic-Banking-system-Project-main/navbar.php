<!-- navbar --> 
      <nav class="navbar navbar-expand-md navbar-dark bg-light">
      <a class="navbar-brand" href="index.php" style="color:black"><img src="img/tsf logo.png" alt="Logo" width="85" style="margin-bottom:4px;"> <b>Spark Foundation Bank</b></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color : black;"><b>Home</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="createuser.php" style="color : black;"><b>Create a User</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="removeuser.php" style="color : black;"><b>Remove user</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transfermoney.php" style="color : black;"><b>Transfer Money</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transactionhistory.php" style="color : black;"><b>Transaction history</b></a>
              </li>
          </div>
       </nav>
