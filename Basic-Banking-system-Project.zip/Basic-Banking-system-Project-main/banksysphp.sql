-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: july 10, 2021 at 04:35 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE `transaction` (
  `sno` int(3) NOT NULL,
  `sender` text NOT NULL,
  `receiver` text NOT NULL,
  `balance` int(8) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`sno`, `sender`, `receiver`, `balance`, `datetime`) VALUES
(1, 'Bheesham', 'Attaullah', 51000, '2022-08-14 14:29:15'),
(2, 'Kamlesh', 'Doalt Ram', 25000, '2022-08-14 18:40:51'),
(3, 'Attaullah', 'Kamlesh', 5000, '2022-08-14 19:16:56'),
(4, 'Bhaghwan das', 'Akash', 26950, '2022-08-14 19:31:07'),
(5, 'Akash', 'Manoj', 7510, '2022-08-14 20:15:14'),
(6, 'Manoj', 'Bhaghwan das', 35100, '2022-08-14 20:15:47'),
(7, 'Dolat', 'Parkash', 3150, '2022-08-14 20:16:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(3) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` varchar(155) NOT NULL,
  `balance` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `gender`, `balance`) VALUES
(1, 'Bheesham', 'bk@gmail.com', 'Male', 89500),
(2, 'Dolat Ram', 'dolat ram@gmail.com', 'Male', 40650),
(3, 'Akash', 'akash@gmail.com', 'male', 167750),
(4, 'Kamlesh', 'kamu@gmail.com', 'Male', 170905),
(5, 'Manoj', 'manoj@gmail.com', 'male', 127350),
(6, 'Attaullah', 'attaullah@gmail.com', 'male', 81000),
(7, 'Dolat', 'dolat@gmail.com', 'Male', 69125),
(8, 'Parkash', 'pk@gmail.com', 'Male', 242300),
(9, 'Bhaghwan das', 'bd@gmail.com', 'Male', 99640),
(10, 'Richa', 'richa@gmail.com', 'Male', 46600);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `sno` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
